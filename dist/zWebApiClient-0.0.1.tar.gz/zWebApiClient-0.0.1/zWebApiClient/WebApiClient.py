import requests
from requests.auth import AuthBase


class WebApiAuth(AuthBase):

    def __init__(self, token):
        self.token = token

    def __call__(self, request):
        request.headers.update({
            'Authorization': f'Bearer {self.token}',
        })
        return request


class WebRequest:
    url = None
    method = None
    response: requests.Response = None
    params: dict = None
    complete = False
    status_code = None

    def __init__(self, method, url, params: dict = None):
        self.method = method
        self.url = url
        self.params = params

    def send(self):
        self.response = requests.request(self.method, self.url, **self.params)
        self.complete = True
        self.status_code = self.response.status_code

    def __repr__(self):
        return f'WebRequest({self.method}, {self.url}, {self.params})'


class WebApiClient:
    @classmethod
    def observer(cls, *args, **kwargs):
        print(*args, **kwargs)

    @classmethod
    def pre_flight(cls, req):
        return req

    @classmethod
    def post_flight(cls, req):
        return req

    def __init__(self, base_url, auth: WebApiAuth):
        self.auth = auth
        self.base_url = base_url

    def __make_url(self, *route_bits):
        route = '/'.join([str(bit) for bit in route_bits])
        return self.base_url + route

    def __create_request(self, method, *route_bits, **kwargs):
        url = self.__make_url(*route_bits)
        params = {'auth': self.auth, **kwargs}
        return WebRequest(method, url, params)

    def __execute(self, req: WebRequest):
        req = self.pre_flight(req)
        req.send()
        req = self.post_flight(req)
        return req

    def get(self, *route_bits, **kwargs):
        req = self.__create_request('GET', *route_bits, **kwargs)
        return self.__execute(req)

    def post(self, *route_bits, **kwargs):
        req = self.__create_request('POST', *route_bits, **kwargs)
        return self.__execute(req)

    def put(self, *route_bits, **kwargs):
        req = self.__create_request('PUT', *route_bits, **kwargs)
        return self.__execute(req)

    def patch(self, *route_bits, **kwargs):
        req = self.__create_request('PATCH', *route_bits, **kwargs)
        return self.__execute(req)

    def delete(self, *route_bits, **kwargs):
        req = self.__create_request('DELETE', *route_bits, **kwargs)
        return self.__execute(req)
